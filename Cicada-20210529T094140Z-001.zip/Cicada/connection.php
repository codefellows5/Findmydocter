<?php 
global $con;
$servername = "localhost";
$username = "root";
$password = "";
$database = "findmydoctor";

$con = mysqli_connect($servername,$username,$password,$database) ;


 ?>